import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';
import {
  ApplicationLinks,
  PowerBIDashboard,
} from '../models/application.model';
import { ApiRequestService } from './api-request.service';
import { CURRENT_PLANT_CODE, PORTAL } from '../app.constants';

/**
 * =====================================================================
 *  ApplicationService
 *  ---------------------------------------------------------------
 *  DUMMY DATA MODE — every method currently returns mock data via
 *  `of(...)` so the UI can be developed / demoed without the backend.
 *
 *  TO GO LIVE: set `USE_DUMMY_DATA = false` and fill in the API
 *  endpoints below. The method signatures match the old application,
 *  so the existing backend contract plugs in unchanged.
 * =====================================================================
 */
@Injectable({ providedIn: 'root' })
export class ApplicationService {
  private readonly USE_DUMMY_DATA = false;

  /** TODO: point these at the real endpoints when integrating. */
  private readonly API_BASE = '/api';
  private readonly TOKEN_URL = `${this.API_BASE}/auth/current-token`;
  private readonly APPS_URL = `${this.API_BASE}/user/applications`;
  private readonly POWERBI_URL = `${this.API_BASE}/user/powerbi-dashboards`;

  constructor(
    private apiRequest: ApiRequestService,
    private http: HttpClient,
  ) {}

  getCurrentToken(): Observable<any> {
    return this.apiRequest.get(`MM_Application/GetTokenCurrent`);
  }

  getUserApplications(token: string): Observable<ApplicationLinks[]> {
    return this.apiRequest.get(`MM_Application/GetUserApplication/${token}`);
  }
  // ------------------------------------------------------------------
  // 3. Power BI dashboards the user can access
  //    (separate call — access logic handled in the backend)
  // ------------------------------------------------------------------
  getPowerBIDashboards(tokenResponse: any): Observable<PowerBIDashboard[]> {
    switch (CURRENT_PLANT_CODE) {
      case 'EPT':
        return of([])
      case 'A003':
        return of(this.Nashik_PowerBI);
        break;
      default:
        return of([]);
    }
    return of();
  }

  // ==================================================================
  //  DUMMY DATA — remove once the real APIs are wired up
  // ==================================================================

  private readonly Nashik_PowerBI: PowerBIDashboard[] = [
    {
      Dashboard_Name: 'Single Page Dashboard',
      Dashboard_Url:
        'https://app.powerbi.com/links/0EuipeLTGJ?ctid=8c4858b5-f020-483a-b7ef-71ded6e81767&pbi_source=linkShare',
      Description: 'All Indicators in a single page',
      Workspace: '',
    },
    {
      Dashboard_Name: 'BIW Dashboard',
      Dashboard_Url:
        'https://app.powerbi.com/links/A1tGU7kpzy?ctid=8c4858b5-f020-483a-b7ef-71ded6e81767&pbi_source=linkShare',
      Description: 'All Body Shops Indicators',
      Workspace: '',
    },
    {
      Dashboard_Name: 'Online & Offline',
      Dashboard_Url:
        'https://app.powerbi.com/links/Dof1ho5gSX?ctid=8c4858b5-f020-483a-b7ef-71ded6e81767&pbi_source=linkShare',
      Description: 'QDMS - Power BI Dashboard',
      Workspace: '',
    },
    {
      Dashboard_Name: 'Audits Analytics Dashboard',
      Dashboard_Url:
        'https://app.powerbi.com/links/mkR35YJq2x?ctid=8c4858b5-f020-483a-b7ef-71ded6e81767&pbi_source=linkShare',
      Description:
        'Consolidated  insights across audits, plants, shops and users',
      Workspace: '',
    },
  ];
}
