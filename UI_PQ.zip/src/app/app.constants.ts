/** Central place for portal-wide links & contact points. */
export const PORTAL = {
  /** Displayed in the header / browser tab. */
  APP_TITLE: 'PQ DRONA',
  TAGLINE: 'From Audits to Insights - Centralizing Quality. Empowering Decisions. Driving Excellence.',

  /** MSolve — raise a support / incident ticket. Replace with the actual MSolve URL. */
  MSOLVE_URL: 'https://msolve.mahindra.com/esc?id=sc_cat_item&sys_id=9526be5a877dfa10c27d84c40cbb35bd',

  /** Support mailbox shown in the footer and support section. */
  SUPPORT_EMAIL: 'PQDronaSupport@mahindra.com',

  COMPANY: 'Mahindra & Mahindra Ltd.',

} as const;

export const CURRENT_PLANT_CODE :string = 'A003'; //Nashik
// export const CURRENT_PLANT_CODE :string = 'CK01'; //Nashik
// export const CURRENT_PLANT_CODE :string = 'EPT'; //Nashik
