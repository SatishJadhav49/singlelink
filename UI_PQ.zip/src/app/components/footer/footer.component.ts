import { Component } from '@angular/core';
import { PORTAL } from '../../app.constants';

@Component({
  selector: 'app-footer',
  standalone: true,
  templateUrl: './footer.component.html'
})
export class FooterComponent {
  readonly portal = PORTAL;
  readonly year = new Date().getFullYear();
  readonly mailtoLink = `mailto:${PORTAL.SUPPORT_EMAIL}?subject=PQ Drona%20Support%20Request`;
}
